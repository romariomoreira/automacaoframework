package gherkin.hook;


import br.com.core.asserts.Verifications;
import br.com.core.integration.OpenStf;
import br.com.core.report.ExtentReports;
import br.com.core.setup.AppWeb;
import br.com.core.view.Action;
import br.com.gft.Encrypt;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import sun.misc.BASE64Decoder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static br.com.core.setup.Drivers.closeDriver;
import static io.restassured.RestAssured.given;
import static io.restassured.path.xml.XmlPath.with;


public class Hook extends ExtentReports {

    OpenStf openStf = new OpenStf();

    @Before
    public void init(Scenario scenario) {
        testScenario.set(scenario);









//        openStf.connectToRemoteDevice("c2e7e45");
//        openStf.commandRemoteADB("adb connect");


        /*WinAppDriver desktop driver start example
        AppWindows app = new AppWindows();
        app.setUpDriver(app);*/

        /*Winium desktop driver start example
        AppWinium app2 = new AppWinium();
        app2.setUpDriver(app2);*/

        /*Web Browser driver start example
        AppWeb app1 = new AppWeb();
        app1.setBrowserName("firefox");
        app1.setUpDriver(app1);*/

        /*Android driver start example*/
       /* AppAndroid app = new AppAndroid();
        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("device", "Google Pixel");
        caps.setCapability("os_version", "7.1");
        caps.setCapability("app", "bs://dfde0754e60179ea442a46ac4a35c5ab6f412398");
        caps.setCapability("name", scenario.getName());
        app.setCapabilities(caps);
        app.setUpDriver(app);*/



    }



    @After
    public void cleanUp() {


//        openStf.commandRemoteADB("adb disconnect");
//        openStf.disconnectToRemoteDevice();

    }
}









