package br.com.pom.enviroment;

public interface EnviromentTaas {

    String zalenium = "http://qa-brazil-server.gft.com:4444/wd/hub";
}
