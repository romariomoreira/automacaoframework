package br.com.core.enums;

public enum DbPlatform {

    ORACLE,
    MYSQL,
    POSTGRESQL;

}
