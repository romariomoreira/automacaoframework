_README em Português [aqui](README.md)_
# SYSTEM-PROJECT-NAME  
Provide a brief description of the project you are developing and what is being tested


## PRE-REQUISITES

Describe any software or hardware that is required in order to execute this automation project

*   Java 1.8 SDK
*   Maven 3.5.*
*   Node.js 8.*
*   Appium install via node version last version
*   WinAppDriver install via node version 1.1

## RUNNING THE TESTS

```
Explain step by step how to run the tests, in case there is some special organization 
that was developed using cucumber tags, for instance.
```

## DEVELOPER COMPANY

Put the name of the company or partner responsible for developing this automation project

## AUTHORS

* **Developer 1**
* **Developer 2**
* **Developer 3**
* **So and so ...**

