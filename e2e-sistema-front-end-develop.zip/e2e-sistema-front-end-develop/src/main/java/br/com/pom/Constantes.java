package br.com.pom;

public interface Constantes {

    int timeOut =10;
}
