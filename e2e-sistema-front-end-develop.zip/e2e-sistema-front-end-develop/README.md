_README in English [here](README.en-us.md)_  
# NOME-PROJETO-SISTEMA

Aplique uma breve descrição do projeto que você está desenvolvendo e o que está sendo testado


## PRÉ-REQUISITOS

Descreva os requisitos de software e hardware que é necessário para executar este projeto de automação

*   Java 1.8 SDK
*   Maven 3.5.*
*   Node.js 8.*
*   Appium install via node version last version
*   WinAppDriver install via node version 1.1

## EXECUTANDO OS TESTES

```
Explique passo a passo como executar os testes, caso exista uma forma de organização especial
que foi desenvolvida atravês de tags do cucumber.
```

## EMPRESA DESENVOLVEDORA

Coloque o nome da empresa ou parceiro que desenvolveu esta automação

## AUTORES

* **Fulano 1**
* **Fulano 2**
* **Fulano 3**
* **Fulano ...**